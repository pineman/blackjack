#include <stdio.h>

void *ecalloc(size_t nmemb, size_t size);
FILE *efopen(const char *path, const char *mode);
