#ifndef MAIN_H
#define MAIN_H

#define MAX_DECK_SIZE 52      // number of max cards in the deck
#define MAX_CARD_HAND 11      // 11 cards max. that each player can hold
#define MAX_PLAYERS 4         // number of maximum players
#define MAX_STR_SIZE 100

#endif
